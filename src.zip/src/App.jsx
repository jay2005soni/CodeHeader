function head(){
  return(
     <div className="w-full h-16 bg-slate-950 text-white flex items-center justify-between px-20">
    
      <nav className="flex space-x-10">
        <a href="#" className="hover:text-slate-300">Home</a>
        <a href="#" className="hover:text-slate-300">About Us</a>
        <a href="#" className="hover:text-slate-300">Contact</a>
        <a href="#" className="hover:text-slate-300">Pricing</a>
      </nav>
    </div>
  )
}
export default head;